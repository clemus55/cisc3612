
#include "get_path.h"

int pid;
int sh( int argc, char **argv, char **envp);
char *which(char *command, struct pathelement *pathlist);
char *where(char *command, struct pathelement *pathlist);
void list ( char *dir );
//void printenv(char **envp);

void killProcess(pid_t pid, int sig);
void setVal(char *arg1, char *arg2);
void setEmptyEnv(char *name);
void printPid();
void newPrefix(char *command, char *p);
void printenv(char **arg);
void printWD();
void StringtoArr(char *input,char** cmds);
void sigStpHandler(int sig) ;
void sigIntHandler(int sig);

#define PROMPTMAX 32
#define MAXARGS 10
