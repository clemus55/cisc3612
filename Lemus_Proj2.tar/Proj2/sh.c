#include <stdio.h>
#include <string.h>
#include <strings.h>
#include <limits.h>
#include <unistd.h>
#include <stdlib.h>
#include <pwd.h>
#include <errno.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <wordexp.h>
#include <signal.h>
#include "sh.h"

#define BUFFERSIZE 128

		
		void StringtoArr(char *input,char** cmds){
			char* temp;
			temp=strtok(input," ");
			if (temp==NULL){

				cmds[0]=malloc(1*sizeof(char));
				cmds[0][0]=0;
				return;
			}
			int len=strlen(temp);
			cmds[0]=malloc(sizeof(char)*len+1);
			strcpy(cmds[0],temp);
			int i=1;
			while ((temp=strtok(NULL," "))!=NULL){
				len=strlen(temp);
				cmds[i]=malloc(sizeof(char)*len+1);
				strcpy(cmds[i],temp);
				i++;
			}
			cmds[i]=NULL;
		
		}

int sh( int argc, char **argv, char **envp )
{
  char *prompt = calloc(PROMPTMAX, sizeof(char));
  char *commandline = calloc(MAX_CANON, sizeof(char));
  char *command, *arg, *commandpath, *p, *pwd, *owd, *cwd;
  char **args = calloc(MAXARGS, sizeof(char*));
  char cmd[64];
  int uid, i, status, argsct, go = 1;
  struct passwd *password_entry;
  char *homedir;
  struct pathelement *pathlist;

  uid = getuid();
  password_entry = getpwuid(uid);               /* get passwd info */
  homedir = password_entry->pw_dir;		/* Home directory to start
						  out with*/
     
  if ( (pwd = getcwd(NULL, PATH_MAX+1)) == NULL )
  {
    perror("getcwd");
    exit(2);
  }
  
  owd = calloc(strlen(pwd) + 1, sizeof(char));
  cwd = calloc(strlen(pwd) + 1, sizeof(char));
  memcpy(owd, pwd, strlen(pwd));
  memcpy(cwd, pwd, strlen(pwd));
  prompt[0] = ' '; prompt[1] = '\0';

	signal(SIGINT, sigIntHandler);
  	signal(SIGTSTP, sigStpHandler);
  	signal(SIGTERM, sigStpHandler);
 

  /* Put PATH into a linked list */
  pathlist = get_path();

  while (go)
  {
    /* print your prompt */
   printf("%s%s>>", prompt, pwd);
    /* get command line and process */
    char buf[BUFFERSIZE];
		fgets (buf,BUFFERSIZE,stdin);
		int len=strlen(buf);
		buf[len-1]=0;
		
	
 /*  if (fgets(commandline, MAX_CANON, stdin) == NULL) {
      printf("ctrl d cannot be used\n");
      fflush(stdout);
      continue;
    }*/


		 StringtoArr(buf,args);
		 
//		if(buf[0]==0 ||args[0] == NULL){
//			printf("using ctrl d \n");
//			continue;
//		}
		 		              
	
		if (!strcmp(args[0],"exit")){
			printf("Executing built-in %s\n", args[0]);
			free(prompt);
		//	free(pathlist);
			free(commandline);
			free(args);
			free(owd);
			free(cwd);

			go=0;
		}

		
    if(strcmp(commandline, "\n") == 0) {
      continue;
    }
		//implements built-in which command
		else if (!strcmp(args[0],"which")){
			char *path = which(args[1], pathlist);
			if (args[1] == NULL)
			{
				printf("Which needs an argument\n");
			} else {
			for (int i = 1;i < MAXARGS; i++){
				if (args[i] != NULL)
				{
					char *path = which(args[i], pathlist);
					if (path)
					{
						
						printf("%s\n", path);
						free(path);
					}
					else
					{
						printf("%s Could Not Find: %s\n", args[0],args[i]);
					}
				}
			}
			}
		}
		//implements built-in where command
		else if (!strcmp(args[0],"where")){
      		char *path = where(args[1], pathlist);
			if (args[1] == NULL)
			{
				printf("Where needs an argument\n");
			} else {
			for (int i = 1;i < MAXARGS; i++){
				if (args[i] != NULL)
				{
					char *path = where(args[i], pathlist);
					if (path)
					{
						
						printf("%s\n", path);
						free(path);
					}
					else
					{
						printf("%s Could Not Find: %s\n", args[0],args[i]);
					}
				}
			}
			}  
    }
	//implements built-in pwd command
	else if (!strcmp(args[0],"pwd"))
    {
	printf("Executing built-in %s\n", args[0]);
      printWD();
    }
	//implements built-in pid command
	else if (!strcmp(args[0], "pid")) {
			printf("Executing built-in %s\n", args[0]);
			printPid();
		}
	//implements built-in prompt command
    else if(!strcmp(args[0],"prompt"))
    {
	printf("Executing built-in %s\n", args[0]);
      newPrefix(args[1],prompt);
    }
	//implements built-in list command
	else if(!strcmp(args[0],"list")){ 
		printf("Executing built-in %s\n", args[0]);
			//list everything if not args
			if (args[0] != NULL && args[1] == NULL && args[2] == NULL)
			{
				list(cwd);
			}
			else
			{
				
				for (int i = 1; i < MAXARGS; i++)
				{
					if (args[i] != NULL)
					{
						printf("[%s]:\n", args[i]);
						list(args[i]);
					}
				}
			} 
	}
	//implements built-in cd command
	else if(!strcmp(args[0],"cd")){
		if (args[2]){
				fprintf(stderr,"Too many arguments\n");
			}
			else if (args[1]) {
				if (!strcmp(args[1],"-")){
					strcpy(pwd,owd);
					free(owd);
					owd = getcwd(NULL,PATH_MAX+1);
					chdir(pwd);
				}
				else {
					free(pwd);
					free(owd);
					owd = getcwd (NULL, PATH_MAX+1);
					chdir(args[1]);
					pwd = getcwd(NULL, PATH_MAX+1);
				}
			}
		
	}
	//implements built-in kill command
	else if(!strcmp(args[0],"kill")){
		if (args[0] != NULL && args[1] != NULL && args[2] == NULL)
			{
				killProcess(atoi(args[1]), 0);
			}
			else if(args[0] != NULL && args[1] != NULL && args[2] != NULL){
				killProcess(atoi(args[2]), -1*atoi(args[1]));
			}
			
	}
	//implements built-in printenv command
	else if(!strcmp(args[0],"printenv")){
		printf("Executing built-in %s\n", args[0]);
      if (args[0] != NULL && args[1] == NULL) { 
        int i = 0;
  			while(envp[i] != NULL){
				  printf("%s\n", envp[i]);
				  i++;
			  }
			  
      }
      else if(args[1] != NULL && args[2] == NULL) { 
        printenv(&args[1]);
      }
      else {
        perror("printenv");
		printf("printenv: Too many arguments.\n");

      }
     
	}
	//implements built-in setenv command
	else if(!strcmp(args[0],"setenv")){
		printf("Executing built-in %s\n", args[0]);
			
			if (args[0] != NULL && args[1] == NULL)
			{ //prints whole environment if ran with no arguments
				int i = 0;
				while (envp[i] != NULL) {
					printf("%s\n", envp[i]);
					i++;
				}
			}
			// run one argument, set as an empty environment variable
			else if (args[1] != NULL && args[2] == NULL){
				setEmptyEnv(args[1]);
			}
			// run with two arguments
			else if(args[1] != NULL && args[2] != NULL) {
				setVal (args[1],args[2]);
				//PATH special case
				if(!strcmp(args[1],"PATH")) {
					free(pathlist);
					pathlist = get_path();
				}
				if (strcmp(args[1], "HOME") == 0) {
					homedir = getenv("HOME");
				}
			}
			else { 
				perror("setenv");
				printf("setenv: Too many arguments.\n");
			}
		}	
			/* end check for each built in command and implement */
		
	
		else{
			int wcIndex = -1;
      		int i = 0;
      		char **wildcard;
      		wordexp_t p;
      			while (args[i])
      			{
        			if (strchr(args[i], '*') || strchr(args[i], '?'))
					{
         		 		wcIndex = i;
						  }
        					i++;
							}
      		if (wcIndex >= 0)
      		{
        		wordexp(args[wcIndex], &p, 0);
       			wildcard = p.we_wordv;
        		args[wcIndex] = NULL;
      			}
			//call which to get the absolute path
			char* cmd=which(args[0],pathlist);
			int pid=fork();
			if (pid){
				free(cmd);
				waitpid(pid,NULL,0);
			}
			 /*  end else  program to exec */
    
      			 /* end find it */
       			/* end do fork(), execve() and waitpid() */
			else{
				if (execve(cmd, args, envp) < 0)
				{
					//If execve() returns a negative value, the program could not be found.
		 			fprintf(stderr, "%s: Command not found.\n", args[0]);
					exit(0);
				}
			}
		}		
      /* else */
        /* fprintf(stderr, "%s: Command not found.\n", args[0]); */
    
  }
  return 0;

 } /* sh() */

//which takes in a char and a struct pathelement, returns char and is used to find locations of exectuables
char *which(char *command, struct pathelement *pathlist)
{
   /* loop through pathlist until finding command and return it.  Return
   NULL when not found. */
     char* result=(char *)malloc(BUFFERSIZE);
	while (pathlist) {         // WHICH
    	sprintf(result, "%s/%s", pathlist->element,command);
    if (access(result, X_OK) == 0) {
      return result;
    }
    pathlist = pathlist->next;
  	}
	  free(result);
	return NULL;


} /* which() */

//where takes in a char and a struct pathelement, returns char and is used to find locations of exectuables
char *where(char *command, struct pathelement *pathlist)
{
  /* similarly loop through finding all locations of command */
  char* result=(char *)malloc(BUFFERSIZE);
	while (pathlist) {         // WHICH
    	sprintf(result, "%s/%s", pathlist->element,command);
    if (access(result, F_OK) == 0) {
      return result;
    }
    pathlist = pathlist->next;
  	}
	  free(result);
	return NULL;

} /* where() */


void list ( char *dir )
{
  /* see man page for opendir() and readdir() and print out filenames for
  the directory passed */
	DIR *direct;
	struct dirent *dent;
	direct = opendir(dir);
	if (direct == NULL)
	{
		perror(dir);
	}
	else
	{
		while ((dent = readdir(direct)) != NULL)
		{
			printf("%s\n", dent->d_name);
		}
	}
	closedir(direct);
} /* list() */

//prints out PWD, returns and inputs nothing
void printWD(){
			char cwd[PATH_MAX];
			getcwd(cwd, sizeof(cwd));
			printf("%s\n", cwd);
			}
		
//prints the whole enviornment, returns nothing and inputs a char
void printenv(char **arg) {
  			char **currEnv = arg;
			printf("%s\n", getenv(*currEnv));
			  }

//inputs 2 char, will input a new prompt prefix
void newPrefix(char *command, char *p) 
{
  char buffer[BUFFERSIZE];
  int len;
  if (command == NULL) 
  {
    command = malloc(sizeof(char) * PROMPTMAX);
    printf("Input new prompt prefix: ");
    if (fgets(buffer, BUFFERSIZE, stdin) != NULL) {
    len = (int) strlen(buffer);
    buffer[len - 1] = '\0';
    strcpy(command, buffer);
    }
    strcpy(p, command);
    free(command);
  }
  else 
  {
    strcpy(p, command);
  }
}

//prints out the pid, inputs and returns nothing
void printPid(){
	printf("");
	int pid = getpid();
	printf("%d\n", pid);
} /* printPid() */

//sets an empty enviornment, inputs a char and returns nothing
void setEmptyEnv(char *name) {
	setenv(name,"",1);
}

// command to set environment when provided more than one command, returns nothing and inputs 2 chars
void setVal(char *arg1, char *arg2) { 
	setenv(arg1,arg2,1);
} /* setVal() */

//function used to kill the current process, inputs a pid_t and int, returns nothing
void killProcess(pid_t pid, int sig){
	if (sig == 0){
		kill(pid,SIGTERM);
	}
	else {
		kill(pid, sig);
	}
}

//signal handler
void sigIntHandler(int sig) {
  signal(SIGINT,sigIntHandler);
  printf("\n Cannot be terminated using Ctrl+C %d \n", waitpid(getpid(),NULL,0));
  fflush(stdout);
  return;
}

//ctrl z handler
void sigStpHandler(int sig) {
  signal(SIGTSTP, sigStpHandler);
  printf("\n Cannot be terminated using Ctrl+Z \n");
  fflush(stdout);
}








